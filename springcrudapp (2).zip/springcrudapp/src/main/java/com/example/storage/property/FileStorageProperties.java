package com.example.storage.property;

import javax.servlet.annotation.MultipartConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
public class FileStorageProperties {
    private String uploadDir = "G:\\JEE.NCLC.M.47\\webproject\\springcrudapp\\uploads";

    public String getUploadDir() {
        return uploadDir;
    }

    public void setUploadDir(String uploadDir) {
        this.uploadDir = uploadDir;
    }
}
